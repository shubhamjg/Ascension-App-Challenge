package com.shubham.ascensionappchallenge.mvvm.repository.base


open class BaseRepositoryImpl : MVVMRepository {
    override fun detach() {}
}