package com.shubham.ascensionappchallenge.mvvm.repository.base

interface MVVMRepository{
    fun detach()
}